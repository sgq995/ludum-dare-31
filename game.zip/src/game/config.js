pandaConfig = {
    name: 'One infected snow', // ??? ._.
    version: '1.0.0',

    system: {
        width: 1024,
        height: 768,
        scaleToFit: true
    },
    
    storage: {
		id: 'com.sgq995.ld31'
	}
};
